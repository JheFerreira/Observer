/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package observer2;

import Classes.Streaming;
import Classes.User;

/**
 *
 * @author Jéssica Ferreira
 */
public class Cliente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Streaming service = new Streaming();
       
        
        User userOne = new  User("User1", "user1@hot.com"); 
        User user2 = new  User ("User2", "user2@hot.com"); 
        User user3 = new  User ("User3", "user3@hot.com"); 
        User user4 = new  User ("User4", "user4@hot.com"); 
        User user5 = new  User ("User5", "user5@hot.com"); 
        
        
        service.subscribe(user5);
        service.subscribe(user4);
        service.subscribe(user3);
        service.subscribe(user2);
        service.subscribe(userOne);
        
        service.upContent("Filme: Guerra Mundial Z");
        userOne.setNotify();
        System.out.println("User3: "+user3.getService().getName());
        service.unsubscribe(user2);
        
        
        
    }
}
    


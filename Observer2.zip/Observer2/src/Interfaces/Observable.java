/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

/**
 *
 * @author Jéssica Ferreira
 */
public interface Observable <O> {
    
    public void subscribe(O user);
    public void unsubscribe(O user);
    public void notification();
    public void upContent(String conteudo);
    
}

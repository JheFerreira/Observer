/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

/**
 *
 * @author Jéssica Ferreira
 */
public interface Observer <O> {
    
    public void update(String up);
    public void subscriptionService(O service);
    public boolean getNotify();
    public void deleteSubscriptionService();
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import Interfaces.Observer;

/**
 *
 * @author Jéssica Ferreira
 */
public class User implements Observer<Streaming>{
    private boolean notify = true;
    private Streaming service;
    private String name;
    private String email;

    public User(String name, String email) {
        this.name = name;
        this.email = email;
    }
    
    @Override
    public void update(String up) {
        System.out.println("Opa " + this.name + " olha a novidade!\n" + up);
    }
    
    @Override
    public void subscriptionService(Streaming service){
        this.service = service;
    }
    
    @Override
    public void deleteSubscriptionService() {
        this.service = null;
    }
    
    @Override
    public boolean getNotify(){
        return this.notify;
    }
    
  //Getters & Setters  
    public Streaming getService() {
        return service;
    }
    
    public void setNotify() {
        this.notify = !this.notify;
    }
    
}
